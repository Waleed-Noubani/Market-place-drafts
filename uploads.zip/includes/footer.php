</main>      <!-- End Main Content --> 
</div>



<footer class="footer">
    <div class="footer-container">
        
        <div class="footer-copyright">
            <p>&copy; <?php echo date('Y'); ?> Freelance Marketplace. All rights reserved.</p>
        </div>
        
        <!-- Footer Links -->
        <div class="footer-links">
            <a href="terms-of-service.php" class="footer-link">Terms of Service</a>
            <span class="footer-separator">|</span>
            <a href="privacy-policy.php" class="footer-link">Privacy Policy</a>
            <span class="footer-separator">|</span>
            <a href="contact-us.php" class="footer-link">Contact Us</a>
        </div>
        
    </div>
</footer>

</body>
</html>